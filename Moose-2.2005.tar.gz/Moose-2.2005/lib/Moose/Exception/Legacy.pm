package Moose::Exception::Legacy;
our $VERSION = '2.2005';

use Moose;
extends 'Moose::Exception';

1;
